import time
import uuid  
from datetime import datetime, timedelta
from coinbase.wallet.client import Client as CoinbaseAPI
from binance.client import Client as BinanceAPI
import json

def trading_decision(predicted_price, current_price, atr):
    if predicted_price > current_price:
        return "BUY"
    elif predicted_price < current_price:
        return "SELL"
    else:
        return "HOLD"


def generate_client_order_id():
    return str(uuid.uuid4())

def execute_trade(client,product,decision, amount, current_price, target_price, stop_loss):

    with open('config.json') as config_file:
        config = json.load(config_file)

    binance_api_key = config['binance']['api_key']
    binance_api_secret = config['binance']['api_secret']
    coinbase_api_key = config['coinbase']['api_key']
    coinbase_api_secret = config['coinbase']['api_secret']

    binance_client = BinanceAPI(binance_api_key, binance_api_secret, tld='us')
    coinbase_client = CoinbaseAPI(coinbase_api_key, coinbase_api_secret)

    if decision == "BUY":

        client_order_id = generate_client_order_id()
        # Ajustar precisión del tamaño de la orden
        quote_size_usd = round(amount, 2)  # Limitar a 2 decimales
        try:
            response = client.market_order_buy(
                client_order_id=client_order_id,
                product_id="BTC-USD",  # Par de mercado
                quote_size=str(quote_size_usd)  # Monto en USD
            )
            print("Orden de compra completada:", response)
        except Exception as e:
            print("Error al realizar la compra:", e)
    
        # Record the start time
        start_time = datetime.now()
        end_time = start_time + timedelta(minutes=15)            

        while datetime.now() < end_time:
            # Fetch current market price
            ticker = binance_client.get_ticker(product_id=product)
            current_price = float(ticker["price"])
            print(f"Current Price: ${current_price:.2f}")

            # Check if profit target or stop loss is hit
            if current_price >= target_price:
                print("Profit target reached. Placing market sell order...")
                sell_order = client.market_order_sell(
                    product_id=product,
                    quote_size=str(quote_size_usd)  # Monto en USD
                )
                print("Sell Order Executed:", sell_order)
                break
            elif current_price <= stop_loss:
                print("Stop loss triggered. Placing market sell order...")
                sell_order = client.market_order_sell(
                    product_id=product,
                    quote_size=str(quote_size_usd)  # Monto en USD
                )
                print("Sell Order Executed:", sell_order)
                break

            # Wait for a short time before checking again
            time.sleep(5)

        else:
            # Step 4: After 15 Minutes, Sell No Matter What
            print("15 minutes passed. Placing market sell order...")
            sell_order = client.market_order_sell(
                product_id=product,
                quote_size=str(quote_size_usd)  # Monto en USD
            )
            print("Sell Order Executed:", sell_order)
