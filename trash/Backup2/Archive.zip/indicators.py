import pandas as pd
import numpy as np

def calculate_technical_indicators(df):
    # Asegúrate de que las columnas sean numéricas
    df['close'] = pd.to_numeric(df['close'], errors='coerce')
    df['open'] = pd.to_numeric(df['open'], errors='coerce')
    df['high'] = pd.to_numeric(df['high'], errors='coerce')
    df['low'] = pd.to_numeric(df['low'], errors='coerce')
    df['volume'] = pd.to_numeric(df['volume'], errors='coerce')
    
    # Elimina filas con valores no válidos
    # df = df.dropna()

    # Cálculo de indicadores técnicos
    df['rsi'] = 100 - (100 / (1 + (df['close'].diff(1).clip(lower=0).rolling(window=14).mean() / abs(df['close'].diff(1)).rolling(window=14).mean())))
    df['sma'] = df['close'].rolling(window=14).mean()
    df['ema'] = df['close'].ewm(span=14, adjust=False).mean()
    df['macd'] = df['close'].ewm(span=12).mean() - df['close'].ewm(span=26).mean()
    df['macd_signal'] = df['macd'].ewm(span=9).mean()

    return df # df.dropna()