<?php
/**
 * Created by Florian Pradines
 */

namespace Skeerel\Exception;

class InvalidStateException extends \Exception {}