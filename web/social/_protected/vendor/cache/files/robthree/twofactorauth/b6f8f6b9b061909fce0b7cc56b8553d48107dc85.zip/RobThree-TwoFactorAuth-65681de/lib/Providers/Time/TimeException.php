<?php

namespace RobThree\Auth\Providers\Time;

use RobThree\Auth\TwoFactorAuthException;

class TimeException extends TwoFactorAuthException {}
