<?php

namespace RobThree\Auth\Providers\Rng;

use RobThree\Auth\TwoFactorAuthException;

class RNGException extends TwoFactorAuthException {}
