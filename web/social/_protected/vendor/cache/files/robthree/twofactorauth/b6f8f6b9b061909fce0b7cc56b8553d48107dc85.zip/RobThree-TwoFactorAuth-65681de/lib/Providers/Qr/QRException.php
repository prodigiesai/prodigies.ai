<?php

namespace RobThree\Auth\Providers\Qr;

use RobThree\Auth\TwoFactorAuthException;

class QRException extends TwoFactorAuthException {}
